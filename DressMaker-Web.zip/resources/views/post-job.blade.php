<?php $page="post-job";?>
@extends('layout.mainlayout')
@section('content')


<!-- Page Content -->
			<div class="content">
				<div class="container">

					<div class="row">
						<div class="col-md-8 offset-md-2">

							<!-- Post A job -->
							<div class="empty-content text-center pt-0 pb-4">
									<h2>Please <span class="orange-text">Login</span> to Post A job </h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut consequat mauris </p>
									<div class="btn-item">
										<a class="btn get-btn" href="{{ route('home') }}">Cancel</a>
										<a class="btn courses-btn" href="/login">GO TO Login</a>
									</div>
							</div>
							<!-- /Post A job -->

						</div>
					</div>

				</div>

			</div>
			<!-- /Page Content -->


        </div>
		<!-- /Main Wrapper -->
@endsection
