		<!-- jQuery -->
		<script src="../assets_admin/js/jquery-3.6.0.min.js"></script>

		<!-- Bootstrap Core JS -->
		<script src="../assets_admin/js/bootstrap.bundle.min.js"></script>

		<!-- Feather Icon JS -->
		<script src="../assets_admin/js/feather.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="../assets_admin/plugins/slimscroll/jquery.slimscroll.min.js"></script>

		<!-- Select2 JS -->
		<script src="../assets_admin/plugins/select2/js/select2.min.js"></script>

		<!-- Datatables JS -->
		<script src="../assets_admin/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../assets_admin/plugins/datatables/datatables.min.js"></script>

		<!-- Datepicker Core JS -->
		<script src="../assets_admin/js/moment.min.js"></script>
		<script src="../assets_admin/js/bootstrap-datetimepicker.min.js"></script>

		<!-- Mask JS -->
		<script src="../assets_admin/js/jquery.maskedinput.min.js"></script>
        <script src="../assets_admin/js/mask.js"></script>

		<!-- Form Validation JS -->
        <script src="../assets_admin/js/form-validation.js"></script>


		<script src="../assets_admin/js/apexcharts1.js"></script>

		<!-- Ck Editor JS -->
		<script src="../assets_admin/js/ckeditor.js"></script>

		<!-- Custom JS -->
		<script src="../assets_admin/js/script.js"></script>

        <script type="text/javascript">

            $(document).ready(function () {

            window.setTimeout(function() {
                $(".alert").fadeTo(3000, 0).slideUp(1000, function(){
                    $(this).remove();
                });
            }, 2000);

            });
        </script>
