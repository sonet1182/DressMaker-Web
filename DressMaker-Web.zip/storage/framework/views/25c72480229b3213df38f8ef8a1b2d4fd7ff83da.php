<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<?php if(Route::is(['pagee'])): ?>
<body class="home-page">
<?php endif; ?>
<?php if(Route::is(['404-page','cancelled-projects','change-password','completed-projects','dashboard','delete-account','deposit-funds','favourites','files','freelancer-cancelled-projects','freelancer-change-password','freelancer-completed-projects','freelancer-dashboard','freelancer-delete-account','freelancer-favourites','freelancer-files','freelancer-invitations','freelancer-invoices','freelancer-membership','freelancer-milestones','freelancer-ongoing-projects','freelancer-payment','freelancer-portfolio','freelancer-profile-settings','freelancer-project-proposals','freelancer-review','freelancer-task','freelancer-transaction-history','freelancer-verify-identity','freelancer-view-project-detail','freelancer-withdraw-money','invited-freelancer','manage-projects','membership-plans','milestones','ongoing-projects','pending-projects','post-job','profile-settings','project-payment','review','tasks','transaction-history','verify-identity','view-project-detail','withdraw-money'])): ?>
<body class="dashboard-page">
<?php endif; ?>
<?php if(Route::is(['forgot-password','login','register'])): ?>
<body class="account-page">
<?php endif; ?>
<?php if(Route::is(['chats','freelancer-chats'])): ?>
<body class="chat-page">
<?php endif; ?>
<?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php if(!Route::is(['chats','freelancer-chats'])): ?>
<?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Dress Maker\Laravel\resources\views/layout/mainlayout.blade.php ENDPATH**/ ?>