        <meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
		<title>DressMaker</title>

		<!-- Favicons -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">

		<!-- Bootstrap Tag CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap-tagsinput/css/bootstrap-tagsinput.css')); ?>">

		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">

		<!-- Fancybox CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>">

		<!-- Owl Carousel CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">

		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">

		<!-- Datatables CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/datatables.min.css')); ?>">

		<!-- Summernote CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/dist/summernote-lite.css')); ?>">

		<!-- Main CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

        <script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>
<?php /**PATH C:\xampp\htdocs\DressMaker-Web\resources\views/layout/partials/head.blade.php ENDPATH**/ ?>