<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							<li class="menu-title"><span>Main</span></li>
							<li class="<?php echo e(Request::is('admin/index_admin') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/index_admin')); ?>"><i data-feather="home"></i> <span>Dashboard</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/categories','admin/sub-category') ? 'active' : ''); ?>">
								<a href="<?php echo e(route('category.list')); ?>"><i data-feather="copy"></i> <span>Categories</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/projects') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/projects')); ?>"><i data-feather="database"></i> <span>Projects</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/designers') ? 'active' : ''); ?>" >
								<a href="<?php echo e(url('admin/designers')); ?>"><i data-feather="users"></i> <span>Designers</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/buyers') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/buyers')); ?>"><i data-feather="user-check"></i> <span>Buyers</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/reports') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/reports')); ?>"><i data-feather="pie-chart"></i> <span>Reports</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/bid-fees','admin/contest-entry-fees','admin/contests-fees','admin/fees','admin/projects-fees') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/fees')); ?>"><i data-feather="package"></i> <span>Fees</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/taxs') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/taxs')); ?>"><i data-feather="file-text"></i> <span>Taxs</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/roles','admin/roles-permission') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/roles')); ?>"><i data-feather="clipboard"></i> <span>Roles</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/skills') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/skills')); ?>"><i data-feather="award"></i> <span>Skills</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/verify-identity') ? 'active' : ''); ?>">
								<a  href="<?php echo e(url('admin/verify-identity')); ?>"><i data-feather="user-check"></i> <span>Verify Identity</span></a>
							</li>
							<li class="<?php echo e(Request::is('admin/change-password','admin/delete-account','admin/email-settings','admin/localization-details','admin/others-settings','admin/payment-settings','admin/seo-settings','admin/settings','admin/social-links','admin/social-settings','admin/tax-types') ? 'active' : ''); ?>">
								<a href="<?php echo e(url('admin/settings')); ?>"><i data-feather="settings"></i> <span>Settings</span></a>
							</li>


							


						</ul>
					</div>
				</div>
			</div>
			<!-- /Sidebar -->
<?php /**PATH C:\xampp\htdocs\Dress Maker\Laravel\resources\views/layout/partials/nav_admin.blade.php ENDPATH**/ ?>